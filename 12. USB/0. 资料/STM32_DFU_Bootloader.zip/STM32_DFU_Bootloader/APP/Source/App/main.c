#include "stm32f10x.h"
#include "GLCD.h"
#include "USART.h"
#include "SPI.h"
#include "ch376inc.h"
#include "ch376.h"
#include "file_sys.h"
#include <stdio.h>
#include <string.h>
#define LED1_ON()   GPIO_SetBits(GPIOB,GPIO_Pin_12);
void GPIO_Configuration(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
		
	//PC5 ��Ϊģ��ͨ��10��������                         
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOC, &GPIO_InitStructure);

   	/* Configure USART1 Tx (PA.09) as alternate function push-pull */
  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOA, &GPIO_InitStructure);
    
  	/* Configure USART1 Rx (PA.10) as input floating */
  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  	GPIO_Init(GPIOA, &GPIO_InitStructure);
}

//ϵͳ�жϹ���
void NVIC_Configuration(void)
{ 
	NVIC_InitTypeDef NVIC_InitStructure; 
  /* Configure the NVIC Preemption Priority Bits */  
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);

	#ifdef  VECT_TAB_RAM  
	  /* Set the Vector Table base location at 0x20000000 */ 
	  NVIC_SetVectorTable(NVIC_VectTab_RAM, 0x0); 
	#else  /* VECT_TAB_FLASH  */
	  /* Set the Vector Table base location at 0x08000000 */ 
	  NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0);   
	#endif

	/* Enable the USARTy Interrupt */
  	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
  	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  	NVIC_Init(&NVIC_InitStructure);
}

//����ϵͳʱ��,ʹ�ܸ�����ʱ��
void RCC_Configuration(void)
{
	SystemInit();	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA 
                           |RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC
                           |RCC_APB2Periph_GPIOD | RCC_APB2Periph_GPIOE
						   |RCC_APB2Periph_ADC1  | RCC_APB2Periph_AFIO 
                           |RCC_APB2Periph_SPI1, ENABLE );
  // RCC_APB2PeriphClockCmd(RCC_APB2Periph_ALL ,ENABLE );
     RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4 
                           |RCC_APB1Periph_USART3|RCC_APB1Periph_TIM2	                           
                           , ENABLE );
	 RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
}

void InitDis(void) 
{
   /* LCD Module init */
   GLCD_init();
   GLCD_clear(White);
   GLCD_setTextColor(Blue);
   GLCD_displayStringLn(Line1, "     FireBull");
   GLCD_displayStringLn(Line2, "   CH376  example");
   GLCD_setTextColor(Red);
}

//������������
void Init_All_Periph(void)
{
	u8 i;
	RCC_Configuration();	
//	InitDis();
//	GLCD_Test();
	GPIO_Configuration();
	NVIC_Configuration();
	USART1_Configuration();
	CH376_Init();
	i=mInitCH376Host();
// 	USART1_SendByte(i);
}

u8 buf[128];
UINT8	TarName[64];
static u8  fac_us=0;//us��ʱ������
static u16 fac_ms=0;//ms��ʱ������
void delay_us(u32 nus)
{		
	u32 temp;	    	 
	SysTick->LOAD=nus*fac_us; //ʱ�����	  		 
	SysTick->VAL=0x00;        //��ռ�����
	SysTick->CTRL=0x01 ;      //��ʼ���� 	 
	do
	{
		temp=SysTick->CTRL;
	}
	while(temp&0x01&&!(temp&(1<<16)));//�ȴ�ʱ�䵽��   
	SysTick->CTRL=0x00;       //�رռ�����
	SysTick->VAL =0X00;       //��ռ�����	 
}

void delay_init(u8 SYSCLK)
{
	SysTick->CTRL&=0xfffffffb;//bit2���,ѡ���ⲿʱ��  HCLK/8
	fac_us=SYSCLK/8;		    
	fac_ms=(u16)fac_us*1000;
}	

void delay_ms(u16 nms)
{	 		  	  
	u32 temp;		   
	SysTick->LOAD=(u32)nms*fac_ms;//ʱ�����(SysTick->LOADΪ24bit)
	SysTick->VAL =0x00;           //��ռ�����
	SysTick->CTRL=0x01 ;          //��ʼ����  
	do
	{
		temp=SysTick->CTRL;
	}
	while(temp&0x01&&!(temp&(1<<16)));//�ȴ�ʱ�䵽��   
	SysTick->CTRL=0x00;       //�رռ�����
	SysTick->VAL =0X00;       //��ռ�����	  	    
} 
void LED_Configuration(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB, ENABLE );
  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13|GPIO_Pin_12;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_Init(GPIOB, &GPIO_InitStructure);

}
int main(void)
{ 
	u8 i; 
	u16	RealCount;
	UINT8  s;
	SCB->VTOR = 0x8000000| 0X10000; /* Vector Table Relocation in Internal FLASH. */
	mDelaymS( 200 );
	mDelaymS( 200 );
	delay_init(72);  //��ʱ��ʼ�� 
	LED_Configuration();
	Init_All_Periph();

	while(1)
 	{
		if(CH376DiskConnect()==USB_INT_SUCCESS)
		{
			delay_ms( 200 );
			for ( i = 0; i < 100; i ++ ) 
			{   
				delay_ms( 50 );
				s = CH376DiskMount( );  //��ʼ�����̲����Դ����Ƿ����.   
				if ( s == USB_INT_SUCCESS ) /* ׼���� */
					break;                                          
				else if ( s == ERR_DISK_DISCON )/* ��⵽�Ͽ�,���¼�Ⲣ��ʱ */
					break;  
				if ( CH376GetDiskStatus( ) >= DEF_DISK_MOUNTED && i >= 5 ) /* �е�U�����Ƿ���δ׼����,�������Ժ���,ֻҪ�佨������MOUNTED�ҳ���5*50mS */
                  break; 
			} 
			strcpy( buf, "\CH376.TXT" );
			if(CH376FileOpen(buf)==USB_INT_SUCCESS)
			{
				strcpy((char *)buf, "DFU���³���Ok" );
				CH376ByteWrite( buf, strlen((const char *)buf), NULL ); /* ���ֽ�Ϊ��λ��ǰλ��д�����ݿ� */
				CH376FileClose( TRUE );   /* �ر��ļ�,�����ֽڶ�д�����Զ������ļ����� */
			}
			LED1_ON();
			while(1);
		}
 	}
}


