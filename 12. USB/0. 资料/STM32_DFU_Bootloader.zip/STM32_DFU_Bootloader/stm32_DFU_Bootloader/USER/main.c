/******************** (C) COPYRIGHT 2012 WildFire Team **************************
 * �ļ���  ��main.c
 * ����    ����3.5.0�汾���Ĺ���ģ�塣         
 * ʵ��ƽ̨��Ұ��STM32������
 * ��汾  ��ST3.5.0
 *
 * ����    ��wildfire team 
 * ��̳    ��http://www.amobbs.com/forum-1008-1.html
 * �Ա�    ��http://firestm32.taobao.com
**********************************************************************************/
#include "stm32f10x.h"
#include "hw_config.h" 
#include "usb_lib.h"
#include "usb_conf.h"
#include "usb_prop.h"
#include "usb_pwr.h"
#include "dfu_mal.h"
#include "delay.h"
#include "usart.h"

u8  RX_Buf[40],RX_Num,flag_cmd,flag_head;
/* Private typedef -----------------------------------------------------------*/
typedef  void (*pFunction)(void);

/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Extern variables ----------------------------------------------------------*/
uint8_t DeviceState;
uint8_t DeviceStatus[6];
pFunction Jump_To_Application;
uint32_t JumpAddress;

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
* Function Name  : main.
* Description    : main routine.
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
int main(void)
{

  delay_init(72);	//��ʼ����ʱ����
  USART1_Init(256000);	//��ʼ������1
 // DFU_Button_Config();

  // Check if the Key push-button on STM3210x-EVAL Board is pressed //
  delay_ms(3000);
  flag_cmd = 1;
  if(!flag_cmd)
 //if (DFU_Button_Read() != 0x00)
  { // Test if user code is programmed starting from address 0x8003000 //  
    if (((*(__IO uint32_t*)ApplicationAddress) & 0x2FFE0000 ) == 0x20000000)
    { //Jump to user application //

      JumpAddress = *(__IO uint32_t*) (ApplicationAddress + 4);
      Jump_To_Application = (pFunction) JumpAddress;
      // Initialize user application's Stack Pointer //
      __set_MSP(*(__IO uint32_t*) ApplicationAddress);
      Jump_To_Application();
    }
  } // Otherwise enters DFU mode to allow user to program his application //
  else if(flag_cmd)
  {
	  flag_cmd = 0;
	  /* Enter DFU mode */
	  DeviceState = STATE_dfuERROR;
	  DeviceStatus[0] = STATUS_ERRFIRMWARE;
	  DeviceStatus[4] = DeviceState;

	  Set_System();
	  Set_USBClock();
	  USB_Init();  
	  
	  /* Main loop */
	  while (1)
	  {}
   }
}



#ifdef USE_FULL_ASSERT
/*******************************************************************************
* Function Name  : assert_failed
* Description    : Reports the name of the source file and the source line number
*                  where the assert_param error has occurred.
* Input          : - file: pointer to the source file name
*                  - line: assert_param error line source number
* Output         : None
* Return         : None
*******************************************************************************/
void assert_failed(uint8_t* file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {}
}
#endif
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

void USART1_IRQHandler(void)
{
	if(USART_GetITStatus(USART1, USART_IT_RXNE) == SET)	   //�ж϶��Ĵ����Ƿ�ǿ�
	{	
		USART_ClearITPendingBit(USART1, USART_IT_RXNE);
		RX_Buf[RX_Num++] = USART_ReceiveData(USART1); 
		if((RX_Num>2)&&((RX_Buf[RX_Num-1]==0xEA)||(RX_Buf[RX_Num-1]==0xE2)))
		{
			if((RX_Buf[RX_Num-2]==0xEA)&&(RX_Buf[RX_Num-3]==0xEA))
			{
				flag_cmd=1;
			}
			USART_ITConfig(USART1,USART_IT_RXNE,DISABLE);
//			RX_Num=0;
		}
		if(RX_Num>40)
		RX_Num=0;
	}

	if(USART_GetFlagStatus(USART1, USART_FLAG_ORE)==SET)
	{
		USART_ClearFlag(USART1, USART_FLAG_ORE);
		USART_ReceiveData(USART1); 
	}  
}



